/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <grlapp.h>
#include <grlabstraction.h>

uint8_t gI2cTransBuffer[512] = {0};
uint8_t gLogBuffer[256] = {0};

#if ONLY_PD_SNK_FUNC_EN

#define BYTELENGTH  8

uint16_t gEventlogBufIndex;
uint8_t gEventlogBuffer[EVNT_LOG_BUF_SIZE];
uint8_t gSOP1AckBuf[64];

#endif/*ONLY_PD_SNK_FUNC_EN*/

#if ONLY_PD_SNK_FUNC_EN
static uint8_t var;
static void timer_expiry_callback(uint8_t instance, timer_id_t id)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    switch(id)
    {
        case GRL_APP_SOP1_TIMER:
            g_Struct_Ptr->gPDSSConfigCtrl.CableIntrRx = false;
            g_Struct_Ptr->gPDSSConfigCtrl.isCableDataReady = false;
            gInitSOP1DiscID();
        break;
    }
  
}
/*Soft timers are identified using a single byte timer ID, and the caller should ensure that the timer ID used does not collide with
timers used elsewhere. This is facilitated by reserving the timer ID range from 0xE0 to 0xFF for use by user application code.
These timer IDs are not used internally within the CCGx firmware stack and are safe for use**/
/* Use a timer to schedule task to be run delay_ms milliseconds later. */
void schedule_task(uint16_t adelay_ms,timer_id_t aTimerID)
{
    /* Start an application timer to wait for delay_ms.
    Devices with two USB-PD ports support two sets of timers, and
    the set to be used is selected using the first parameter. */
    timer_start(0, aTimerID, adelay_ms, timer_expiry_callback);
}

#if 0
    
/**This function can be used if needed to decode every PDO and push only specific required info*/    
void g_fill_DiscID_PDO_info(uint8_t aPresentPDOIndex, const pd_do_t* ACK_VDO, uint8_t *aBuffer)
{
    switch(aPresentPDOIndex)
    {
        case 0:
        
        break;
        case 1:
        
        break;
        
    }
}
#endif

void g_Decode_Rx_Ack_Hdr(pd_packet_extd_t* rx_pd_packet,uint8_t *aBuffer, uint8_t * aBufIndex)
{
    /**decoding header and pushing into buffer*/
    aBuffer[*aBufIndex] = rx_pd_packet->hdr.val; 
    *aBufIndex = *aBufIndex + 1;
    
    aBuffer[*aBufIndex] = rx_pd_packet->hdr.val >> 8; 
    *aBufIndex = *aBufIndex + 1;
}

void g_Decode_Rx_PayloadData(pd_packet_extd_t* rx_pd_packet,uint8_t *aBuffer, uint8_t * aBufIndex,uint8_t aPDOCount)
{
    /**Filling received PDOs into Buffer*/
    for(uint8_t index = 0 ; index < aPDOCount; ++index)
    {
        //g_fill_DiscID_PDO_info(index , &rx_pd_packet->dat[index], aBuffer);
        /**Taking Each PDO data and filling data into buffer by looping */
        for(uint8_t i =0,j=0; i < 4; j+=8,++i )
        {
            aBuffer[*aBufIndex] |= (rx_pd_packet->dat[index].val >> j); 
            *aBufIndex = *aBufIndex + 1;
        }
    }
}

uint8_t g_Decode_Rx_Ack()
{
    static pd_packet_extd_t* rx_pd_packet ;
    rx_pd_packet = pd_phy_get_rx_packet(0);
    
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    g_Struct_Ptr->gPDSSConfigCtrl.gSOP1AckBufIndexCount = 0;
    
    uint8_t lBufIndex=0, lPDOLength = 0;
  
    memset(&gSOP1AckBuf[0], 0x00, 64);
    
    /**soptype into Upper nibble*//**Cmd Type to lower nibble*/
    gSOP1AckBuf[lBufIndex++] = ((rx_pd_packet->sop << 4) | (rx_pd_packet->dat[0].std_vdm_hdr.cmd_type & 0x03) | ((g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC & 0x01) << 2)) ;
    
   /* gSOP1AckBuf[lBufIndex] |= (rx_pd_packet->dat[0].std_vdm_hdr.cmd_type & 0x03);
    gSOP1AckBuf[lBufIndex++] |= (g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC << 2);*/
    
    gSOP1AckBuf[lBufIndex++] = lPDOLength = rx_pd_packet->len;
    
    gSOP1AckBuf[lBufIndex++] =  rx_pd_packet->hdr.val;
    gSOP1AckBuf[lBufIndex++] =  (rx_pd_packet->hdr.val >> BYTELENGTH);
    
    for(uint8_t i =0; i < lPDOLength; ++i )
    {
        for(uint8_t j=0; j<4; j++)
            gSOP1AckBuf[lBufIndex++] |= (rx_pd_packet->dat[i].val >> (BYTELENGTH*j) );
    }
    /**Decoding Received ACK Header*/
    //g_Decode_Rx_Ack_Hdr(rx_pd_packet,gSOP1AckBuf, &lBufIndex);
    
    /**storing received PDOs length*/
    
    
    /**Decoding received Payload data*/
    //g_Decode_Rx_PayloadData(rx_pd_packet,gSOP1AckBuf,&lBufIndex,lPDOLength);
    
    return lBufIndex;
}
#endif /*ONLY_PD_SNK_FUNC_EN*/

/*
*Pranay 07Jun'19, CCG3PA PD subsystem status related controls will be handled here
*/
void g_PDSS_Status(uint8_t * RecvBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
#if ONLY_PD_SNK_FUNC_EN    
    if(RecvBuffer[3] == GRL_BC12_SCOPE)
        gBC12_DataManager(RecvBuffer);
    else
#endif /*ONLY_PD_SNK_FUNC_EN*/
    { 
        g_Get_PDNegotiationInfo(RecvBuffer, gLogBuffer);   
        memcpy(&gI2cTransBuffer[0], &gLogBuffer[0], 128);
    }
    
}
/*
*Prasanna 15May'19; CCG3PA PD Subsystem Block releated control will be handled 
*/
void g_PDSS_Config(uint8_t * aBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
   int lApilength = aBuffer[1];
    switch(aBuffer[5])
    {
        case DATA_MSG_REQUEST:
        if(aBuffer[lApilength+2] == 0xCD)
        {
           g_typec_Pd_Data_Msg_Send(aBuffer);
           pd_prot_send_ctrl_msg(G_PORT0, 0x00, CTRL_MSG_GET_SOURCE_CAP);//initiating GetSrcCaps here, so that the configured request packet will be initiated.
        }
        break;
#if ONLY_PD_SNK_FUNC_EN   
        case DATA_MSG_VDM:
        default:
        if(aBuffer[lApilength+2] == 0xCD)
        {
            g_typec_Pd_Data_Msg_Send(aBuffer);
        }
     
        break;
#endif/*ONLY_PD_SNK_FUNC_EN*/        
    }
}

#if ONLY_PD_SNK_FUNC_EN
/*
*Prasanna 15May'19; Controlling PD Submodules of CCG3PA for the GRL Application
*/
void gPDSS_Control(uint8_t * aBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    uint8_t CmdType = (aBuffer[6]);
    switch(CmdType)
    {
        case CableConnection_Attach:
            typec_start(G_PORT0);
            break;
        case CableConnection_Detach:
            typec_stop(G_PORT0);
            
            break;
            
        case ControlTestAutomation_Start:
            
            break;
        case ControlTestAutomation_Stop:
            //should add Start/Stop TestAutomation
            break;
        case SoftReset :
             pd_prot_send_ctrl_msg(G_PORT0, 1, CTRL_MSG_SOFT_RESET);
            break;
        case HardReset:
            //Second arg. is reason for sending Hard reset.
            dpm_send_hard_reset(G_PORT0, 1);
            break;
        
        default:
        
            break;
    }    
}

bool gBC12_DataManager(uint8_t * lAppBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    bool lRetStatus = false;  
//    bool bc_Status;
    //const bc_status_t *bc_stat;
    bc_status_t gl_bc_status[NO_OF_BC_PORTS];
    bc_status_t *bc_stat = &gl_bc_status[BC_PORT_0_IDX];
    switch(lAppBuffer[4])
    {       
        case GRL_APP_CONFIG:
        /* In BC1.2 we will only tell FX3 that what kind of Provider is connected, which will be tracked in bc_stat->cur_mode
         * whether is it DCP SDP or CDP, based on that will set write 1,2,3 respc. 
         * in to I2C Buf. which will be read in the FX3 and hence Eload'ing(drawing current)
         * needs to be handled according to the DUT type.
         * for DCP Max Current is 1.5A, 
         * for CDP and SDP Max. Current is 500mA if configured. 
         */ 
//         bc_start(BC_PORT_0_IDX, BC_PORT_SINK);
       // bc_stat  = bc_get_status(0);
        var = bc_stat->bc_fsm_state;
         gI2cTransBuffer[1] = 7;//ByteCount
         gI2cTransBuffer[2] = 0xFC;
         gI2cTransBuffer[3] = bc_stat->bc_fsm_state;
         gI2cTransBuffer[4] = bc_stat->bc_evt ;
         gI2cTransBuffer[5] = bc_stat->connected ;
         gI2cTransBuffer[6] = bc_stat->attach ;
         gI2cTransBuffer[7] = bc_stat->cur_mode ;
       // gGet_BC12DUTConfig(lAppBuffer,var,gI2cTransBuffer);
        memset(&gI2cTransBuffer[8], 0x00, (250-8));
        break;
            
        case CableConnection_Attach:
//        bc_start(BC_PORT_0_IDX, BC_PORT_SINK);
        break; 
        case CableConnection_Detach:   
//        bc_stop(BC_PORT_0_IDX);  
        break;
        
        case GRL_APP_STATUS:
//        bc_Status = bc_is_active(0);
        gI2cTransBuffer[2] = 0xFE;
//        gI2cTransBuffer[3] = bc_Status;
        
        break;
        case 0x07:
  
        break;
        default:
        break;
    }
          lRetStatus = true;

        return lRetStatus;
}
void gMiscHandler(uint8_t * lAppBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    switch (lAppBuffer[5])
    {
        case 0x01: /**Initiate UVDM message to get DUT FW version, applicable only to cypress chips, VDM_GET_DEVICE_VERSION **/
                prepareGetDevVersionPkt();
            break;
        case 0x02:/**clearing log buffer and index*/
            gBufLog(true,0);
            
        break;
        case 0x03:
            dpm_downgrade_pd_port_rev(G_PORT0);
            break;
        case 0x04:
            g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC = lAppBuffer[6];
            if( !g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC )
            {
                memset(gSOP1AckBuf,0x00,64);
                g_Struct_Ptr->gPDSSConfigCtrl.gSOP1AckBufIndexCount = 0;
                g_Struct_Ptr->gPDSSConfigCtrl.gVUPStateMachineType = CCG_AS_SNK_ONLY;
                g_Struct_Ptr->gPDSSConfigCtrl.Cable_ResponseConfig = RES_TYPE_IGNORE;
                pd_phy_refresh_roles(0);
                g_Struct_Ptr->gPDSSConfigCtrl.isCableDataReady = false;
            }
            break;
        case 0x05:
            g_Struct_Ptr->gPDSSConfigCtrl.Cable_ResponseConfig = lAppBuffer[6];
            break;
        case 0x06:
//            bc_init(0);
            CyDelay(10);
//            chgb_enable(0);
            break;
            
        case 0x07:
            
            #if 0
            CHGB_SINK_TERM_SPD = 0,             /**< Standard port detect */
            CHGB_SINK_TERM_PCD,                 /**< Primary charger detect. */
            CHGB_SINK_TERM_SCD,                 /**< Secondary charger detect. */
            CHGB_SINK_TERM_AFC,                 /**< AFC detect */
            CHGB_SINK_TERM_APPLE                /**< Apple detect */
                
                
            #endif
            //grl_chgb_apply_sink_term(0,lAppBuffer[6]);
            //chgb_apply_sink_term (0, lAppBuffer[6]);
            
            break;
        case 0x08:
//            chgb_remove_term(0);
            break;
        case 0x09:
//            chgb_apply_dp_pd(0);
            break;
        case 0x0A:
//            chgb_apply_sink_term (0, lAppBuffer[6]);
            break;
            
 
    }
}
#endif/*ONLY_PD_SNK_FUNC_EN*/
/*
Pranay,07Jun'19, Adding PD related setting/getting info here.
lRetStatus :: should be false for every case other than GRL_APP_STATUS in which we'll be reading DUTs data.
*/
bool gPD_DataManager(uint8_t * lAppBuffer)
{
    const dpm_status_t *dpm_stat = dpm_get_info(G_PORT0);
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();

    bool lRetStatus = false;
   // gI2cTransBuffer[2] = lAppBuffer[2];                                             
    switch(lAppBuffer[4])
    {
        case GRL_CABLE_DETACH :

        g_Struct_Ptr->RequestPacketConfig.isDUT_FallBack = false;
        typec_stop(G_PORT0);
        CyDelay(1);
        dpm_stop (G_PORT0);
        CyDelay(1);
        dpm_typec_command(G_PORT0, DPM_CMD_PORT_DISABLE,NULL);
        CyDelay(1);
        typec_stop(G_PORT0);
        CyDelay(1);
        dpm_stop (G_PORT0);
        CyDelay(1);
        dpm_typec_command(G_PORT0, DPM_CMD_PORT_DISABLE,NULL);
        g_Struct_Ptr->RequestPacketConfig.gCustomConfig = 0;
        
        /**Pranay,22Feb21, When we detach ourselves we wont be getting any interrupt, so reverting back to def PDC after explicit detach**/        
        g_Struct_Ptr->RequestPacketConfig.gRequestEnableFlag = false;
       
        g_Struct_Ptr->RequestPacketConfig.isDUT_FallBack = false;
        g_Struct_Ptr->RequestPacketConfig.gPDO_Index = 1;
        g_Struct_Ptr->RequestPacketConfig.gMax_Op_I = 0x32;
        g_Struct_Ptr->RequestPacketConfig.gOperating_I = 0x0A;
        g_Struct_Ptr->RequestPacketConfig.gPDO_Type = PDO_FIXED_SUPPLY;
        break;
        case GRL_CABLE_ATTACH :
        if( dpm_stat->contract_exist != PD_CONTRACT_NEGOTIATION_SUCCESSFUL)//Pranay,20Feb'2020, if already attached no need of attaching again,so if api received neglecting it.
        {
        gpio_set_value (GPIO_PORT_1_PIN_1,1);
        g_Struct_Ptr->RequestPacketConfig.isDUT_FallBack = false;
        g_Struct_Ptr->RequestPacketConfig.gDetachFlag = false;
        dpm_update_port_config (G_PORT0, PRT_ROLE_SINK, PRT_ROLE_SINK, false, false);
        typec_start(G_PORT0);
        dpm_start (G_PORT0);
        }
        break;
        case GRL_TesterMode_SINK :
        g_Struct_Ptr->RequestPacketConfig.isDUT_FallBack = false;
        dpm_stop (G_PORT0);
        dpm_update_port_config (G_PORT0, PRT_ROLE_SINK, PRT_ROLE_SINK, false, false);
        dpm_start (G_PORT0);
        break;
#if ONLY_PD_SNK_FUNC_EN            
        case GRL_CCLines_Handle :
         g_typec_Resistance_Set(lAppBuffer);
        
        break;

        case GRL_CAPABILITY_MISMATCH_HANDLE://0xF1
         g_CapabilityMismatchHandler(lAppBuffer);
        break;
#endif /*ONLY_PD_SNK_FUNC_EN*/
        case GRL_APP_CONFIG :
         g_PDSS_Config(lAppBuffer);
        break;
#if ONLY_PD_SNK_FUNC_EN        
        case GRL_APP_CMD_INIT ://0x10
        
            if(((lAppBuffer[5] & 0xF0)>>4)== 0x01)//If Ctrlmsg needs to be initated
            {
               g_typec_Pd_Ctrl_Msg_Send(lAppBuffer); 
            }
            else if(((lAppBuffer[5] & 0xF0)>>4)== 0x02)//If Extnd msg needs to be initated
            {
                g_typec_Pd_Extd_Msg_Send(lAppBuffer);
            }
            else if(((lAppBuffer[5] & 0xF0)>>4)== 0x00)//If data msg needs to be initated
            {    
            }
            else//If need to Initiate any other commands
            {
                gPDSS_Control(lAppBuffer);
            }
         break;   
        case GRL_MISC_HANDLE ://0xF2
            gMiscHandler(lAppBuffer);
        break;
#endif/*ONLY_PD_SNK_FUNC_EN*/    
    }    
    return lRetStatus;
}
/**/

bool gDataManager(uint8_t * lAppBuffer)
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    bool lRetStatus = false;
#if ONLY_PD_SNK_FUNC_EN
    /**Pranay, 16Jul'21,Restarting timer if we get any API from user/application/TC expecting that received API will be handled in 200mS max
    * if Detach/Attach cmd is received - this timer will be handled in appevt handler itself.  
    */
    if( (g_Struct_Ptr->gPDSSConfigCtrl.gVUPStateMachineType == CCG_AS_CABLE_TESTER )&&
        (!g_Struct_Ptr->gPDSSConfigCtrl.isCableDataReady) && 
        (g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC)
       )
    {
        timer_stop(0,GRL_APP_SOP1_TIMER);
        schedule_task(200, GRL_APP_SOP1_TIMER);
    }
#endif /**ONLY_PD_SNK_FUNC_EN*/    

    if((lAppBuffer[0] & 0x0F)== 0x07)//Get
    {

       g_PDSS_Status(lAppBuffer);
            
            lRetStatus = true;
                   
            gI2cTransBuffer[0] = 0xFA;
    }
    else if((lAppBuffer[0] & 0x0F) == 0x01)//Set
    {
        switch(lAppBuffer[3])
        {
            case GRL_PD_SCOPE:
            
            lRetStatus = gPD_DataManager(lAppBuffer);
              
            break;
#if ONLY_PD_SNK_FUNC_EN
            case GRL_BC12_SCOPE:
            
            lRetStatus =  gBC12_DataManager(lAppBuffer);
            
            break;
#endif /**ONLY_PD_SNK_FUNC_EN*/    

            default:
                
                break;
            
        }
    }
    else if((lAppBuffer[0] & 0x0F) == 0x02)//Programming
    {
        switch(lAppBuffer[3])
        {
            case 0x0F://Switch back to the Boot loader
            
            Bootloadable_1_Load();
              
            break;  
            
            /**Pranay,29Sept'20, For updating DUTs FW through CC lines using uVDMs, sequence will come under FW update section so implementing here aswell */
            case GRL_PD_SCOPE :/**0x03*/
            
            lRetStatus = gPD_DataManager(lAppBuffer);
            
            break;
        }
    }
    return lRetStatus;
}
/*
*Prasanna 15May'19;I2c Communication task handle, I2C Data received from the master will be handled here
*/
void gI2cHandle_task()
{   
    bool isRead = false;
   
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    if((0 != gI2cTransBuffer[0]) && (0xFA != gI2cTransBuffer[0]))
    {
        isRead = gDataManager(gI2cTransBuffer);
        if(!isRead)
            memset(&gI2cTransBuffer[0], 0x00, 250);
    }  
}

/*
*Prasanna 15May'19; i2c Slave SCB initialization for communication between FX3 and CCG3PA
*/
void i2cDevice_Init()
{    
    EZI2C_1_Start();
    
    EZI2C_1_EzI2CSetBuffer1(512, 250, gI2cTransBuffer);
    
    
}

/*
*Prasanna 15May'19; GRL Application Initializtion, SCB's, GPIO's are initialized and the system default configuration states are initialized here
*/
void grlapp_Initialization()
{
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    i2cBuf[0] = 0x00;
    i2cBuf[1] = 0x00;
    g_Struct_Ptr->RequestPacketConfig.gDetachFlag  = true;
     
    g_Struct_Ptr->RequestPacketConfig.gPDO_Index = 1;
    g_Struct_Ptr->RequestPacketConfig.gMax_Op_I = 0x32;
    g_Struct_Ptr->RequestPacketConfig.gOperating_I = 0x0A;
    g_Struct_Ptr->RequestPacketConfig.gPDO_Type = PDO_FIXED_SUPPLY;

#if ONLY_PD_SNK_FUNC_EN

    g_Struct_Ptr->RequestPacketConfig.isDUT_FallBack = false;
    g_Struct_Ptr->RequestPacketConfig.Capability_Mismatch = false;
    g_Struct_Ptr->RequestPacketConfig.gCustomConfig = 0;
    
    g_Struct_Ptr->gPDSSConfigCtrl.gDrSwapSent = false;
    g_Struct_Ptr->gPDSSConfigCtrl.isRuntime_SnkCapsConfigEnabled = true;
    
    g_Struct_Ptr->gPDSSConfigCtrl.gFromBufIndex = 0;
    
    g_Struct_Ptr->gPDSSConfigCtrl.Cable_ResponseConfig = RES_TYPE_IGNORE;
  
    g_Struct_Ptr->gPDSSConfigCtrl.gStartSOP1DiscIDAfterPDC = false;
    g_Struct_Ptr->gPDSSConfigCtrl.isCableDataReady = false;
#endif /**ONLY_PD_SNK_FUNC_EN*/

}

void grlSystem_init()
{   
    i2cDevice_Init();
    g_Struct_Ptr = (grl_Struct_t *)get_grl_struct_ptr();
    grlapp_Initialization();
    /**Pranay,22Aug'19, Changed default drive mode to Pull-up from pull-down beacause FX3 is configured for Active Low interrupt*/
    gpio_hsiom_set_config (GPIO_PORT_1_PIN_2, HSIOM_MODE_GPIO, GPIO_DM_RES_UP, true);
    
    gpio_hsiom_set_config (GPIO_PORT_1_PIN_1, HSIOM_MODE_GPIO, GPIO_DM_RES_UP, true); /**Pranay,19Sept'19,Gpio Added for checking the throughput of API's */
    
}


const grl_Struct_t * get_grl_struct_ptr()
{
    return (&gStruct_t);
}
